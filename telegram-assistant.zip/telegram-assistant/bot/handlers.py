"""
هندلرهای ربات.
تو این مرحله (MVP) فقط دستور /start و اکوی پیام رو داریم.
مرحله بعدی (اتصال به Claude) اینجا جایگزین اکو میشه.
"""
import logging
from telegram import Update
from telegram.ext import ContextTypes

logger = logging.getLogger(__name__)


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    await update.message.reply_text(
        f"سلام {user.first_name}! من دستیار هوشمندت هستم.\n"
        f"فعلا در حال ساخته‌شدنم، ولی به زودی می‌تونم حرفات رو یادم بمونه و کارات رو مدیریت کنم."
    )
    logger.info(f"User {user.id} started the bot")


async def echo_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """فعلا فقط پیام رو تکرار می‌کنه. مرحله ۳ اینجا به Claude وصل میشه."""
    text = update.message.text
    await update.message.reply_text(f"گفتی: {text}")
    logger.info(f"Echoed message from {update.effective_user.id}")

"""
اینجا Application تلگرام رو می‌سازیم و هندلرها رو ثبت می‌کنیم.
این فایل جدا از app.py هست تا بعدا بشه بدون Flask هم تستش کرد.
"""
from telegram.ext import Application, CommandHandler, MessageHandler, filters

from config import TELEGRAM_BOT_TOKEN
from bot.handlers import start_command, echo_message


def build_application() -> Application:
    application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo_message))

    return application
